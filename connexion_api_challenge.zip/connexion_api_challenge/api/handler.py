def get_post(post_id):
    post = {
        "id": post_id,
        "title": f"Post {post_id} Title",
        "body": f"This is a placeholder post with ID {post_id}."
    }
    return post, 200