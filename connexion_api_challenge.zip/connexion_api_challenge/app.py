import connexion

app = connexion.App(__name__, specification_dir='.')
app.add_api(
    "openapi.yaml",
    strict_validation=True,
    swagger_ui=True,
    swagger_url="/docs"  # This is the key!
)

if __name__ == "__main__":
    app.run(port=8080, debug=True)